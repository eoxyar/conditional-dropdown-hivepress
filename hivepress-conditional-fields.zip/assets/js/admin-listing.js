/**
 * HivePress Conditional Fields - Admin Listing Edit
 * For wp-admin listing edit page
 */

jQuery(document).ready(function ($) {
    const conditionalData = window.hpcfConditionalData || {};
    
    console.log('HPCF Admin: Initializing');

    // Process each field pair
    $.each(conditionalData, function(parentFieldName, config) {
        const childFieldName = config.child_field;
        const data = config.data;
        
        // In admin, fields might have hp_ prefix
        let $parent = $('select[name="hp_' + parentFieldName + '"]');
        let $child = $('select[name="hp_' + childFieldName + '"]');
        
        // Try without prefix if not found
        if (!$parent.length) {
            $parent = $('select[name="' + parentFieldName + '"]');
        }
        if (!$child.length) {
            $child = $('select[name="' + childFieldName + '"]');
        }
        
        if (!$parent.length || !$child.length) {
            console.log('HPCF Admin: Fields not found');
            return;
        }
        
        console.log('HPCF Admin: Setting up', parentFieldName, '->', childFieldName);

        /**
         * Update child options
         */
        function updateChildOptions(selectedParent, preserveValue) {
            const children = data[selectedParent] ? Object.keys(data[selectedParent]) : [];
            const currentVal = preserveValue || $child.val();
            
            $child.empty();
            
            // Add empty option
            $child.append(new Option('', '', false, false));
            
            // Add all child options if no parent selected
            if (!selectedParent) {
                $.each(data, function(parent, childrenObj) {
                    $.each(childrenObj, function(childVal, _) {
                        if ($child.find('option[value="' + childVal + '"]').length === 0) {
                            $child.append(new Option(childVal, childVal));
                        }
                    });
                });
            } else if (children.length) {
                $.each(children, function (_, childValue) {
                    $child.append(new Option(childValue, childValue));
                });
            }
            
            // Restore value if exists
            if (currentVal && $child.find('option[value="' + currentVal + '"]').length) {
                $child.val(currentVal);
            }
        }

        // Handle parent change
        $parent.on('change', function (e) {
            e.stopPropagation();
            updateChildOptions($(this).val());
        });

        $child.on('change', function (e) {
            e.stopPropagation();
        });

        // Initial setup
        const initialChildVal = $child.val();
        if ($parent.val()) {
            updateChildOptions($parent.val(), initialChildVal);
        }
    });
});
