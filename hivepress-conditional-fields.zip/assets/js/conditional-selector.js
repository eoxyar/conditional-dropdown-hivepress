/**
 * HivePress Conditional Fields - Frontend Selector
 * Following the working reference plugin pattern with Select2 support
 */

jQuery(document).ready(function ($) {
    const conditionalData = window.hpcfConditionalData || {};
    
    console.log('HPCF: Initializing with data:', Object.keys(conditionalData));

    // Process each field pair
    $.each(conditionalData, function(parentFieldName, config) {
        const childFieldName = config.child_field;
        const data = config.data;
        
        // Find the parent and child selects
        const $parent = $('select[name="' + parentFieldName + '"]');
        const $child = $('select[name="' + childFieldName + '"]');
        
        if (!$parent.length || !$child.length) {
            console.log('HPCF: Fields not found for', parentFieldName, '->', childFieldName);
            return;
        }
        
        console.log('HPCF: Setting up', parentFieldName, '->', childFieldName);

        // Initialize Select2 if available
        if ($.fn.select2) {
            $parent.select2({ placeholder: 'Please Select', allowClear: true });
            $child.select2({ placeholder: 'Please Select', allowClear: true });
        }

        /**
         * Update child options based on selected parent
         */
        function updateChildOptions(selectedParent) {
            const children = data[selectedParent] ? Object.keys(data[selectedParent]) : [];
            
            console.log('HPCF: Updating children for', selectedParent, '- found:', children.length);
            
            $child.empty();
            
            if (children.length) {
                // Add empty option
                $child.append(new Option('', '', false, false));
                // Add child options
                $.each(children, function (_, childValue) {
                    $child.append(new Option(childValue, childValue));
                });
            } else {
                $child.append(new Option('', '', false, false));
            }
            
            // Trigger change for Select2
            $child.val(null).trigger('change');
        }

        // Handle parent change - STOP PROPAGATION to prevent HivePress form refresh
        $parent.on('change', function (e) {
            e.stopPropagation();
            updateChildOptions($(this).val());
        });

        // Also stop propagation on child change
        $child.on('change', function (e) {
            e.stopPropagation();
        });

        // Initial population if parent already has a value
        if ($parent.val()) {
            // Store current child value
            const currentChildVal = $child.val();
            
            updateChildOptions($parent.val());
            
            // Restore child value if it exists in new options
            if (currentChildVal && $child.find('option[value="' + currentChildVal + '"]').length) {
                $child.val(currentChildVal).trigger('change');
            }
        } else {
            $child.empty().append(new Option('', '', false, false)).val(null).trigger('change');
        }
    });
});
