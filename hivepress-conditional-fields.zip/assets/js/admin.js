/**
 * HivePress Conditional Fields - Admin JavaScript
 */

(function($) {
    'use strict';

    // Initialize on document ready
    $(document).ready(function() {
        initBulkActions();
        initImportForm();
    });

    /**
     * Initialize bulk actions
     */
    function initBulkActions() {
        var $selectAll = $('#hpcf-select-all');
        var $checkboxes = $('.hpcf-item-checkbox');
        var $bulkDelete = $('#hpcf-bulk-delete');

        // Select all toggle
        $selectAll.on('change', function() {
            $checkboxes.prop('checked', $(this).is(':checked'));
            updateBulkButton();
        });

        // Individual checkbox
        $checkboxes.on('change', function() {
            updateBulkButton();
            
            // Update select all state
            var allChecked = $checkboxes.length === $checkboxes.filter(':checked').length;
            $selectAll.prop('checked', allChecked);
        });

        // Bulk delete
        $bulkDelete.on('click', function() {
            var ids = $checkboxes.filter(':checked').map(function() {
                return $(this).val();
            }).get();

            if (ids.length === 0) {
                return;
            }

            if (!confirm(hpcf_admin.strings.confirm_delete)) {
                return;
            }

            $.ajax({
                url: hpcf_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'hpcf_bulk_delete',
                    nonce: hpcf_admin.nonce,
                    ids: ids
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message || 'Error occurred');
                    }
                },
                error: function() {
                    alert('Request failed');
                }
            });
        });

        function updateBulkButton() {
            var checkedCount = $checkboxes.filter(':checked').length;
            $bulkDelete.prop('disabled', checkedCount === 0);
        }
    }

    /**
     * Initialize import form
     */
    function initImportForm() {
        var $form = $('#hpcf-import-form');
        var $progress = $('#hpcf-import-progress');
        var $results = $('#hpcf-import-results');
        var $btn = $('#hpcf-import-btn');

        $form.on('submit', function(e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append('action', 'hpcf_import_csv');
            formData.append('nonce', hpcf_admin.nonce);

            // Show progress
            $btn.prop('disabled', true);
            $progress.show();
            $results.hide();

            $.ajax({
                url: hpcf_admin.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    $progress.hide();
                    $btn.prop('disabled', false);
                    
                    if (response.success) {
                        var html = '<div class="result-stats">';
                        html += '<strong>' + response.data.imported + '</strong> imported, ';
                        html += '<strong>' + response.data.skipped + '</strong> skipped';
                        html += '</div>';
                        
                        if (response.data.errors && response.data.errors.length > 0) {
                            html += '<div class="result-errors">';
                            html += '<strong>Warnings:</strong><br>';
                            html += response.data.errors.join('<br>');
                            html += '</div>';
                        }
                        
                        $results.html(html).removeClass('error').addClass('success').show();
                    } else {
                        $results.html('<p>' + (response.data.message || 'Import failed') + '</p>')
                               .removeClass('success').addClass('error').show();
                    }
                },
                error: function() {
                    $progress.hide();
                    $btn.prop('disabled', false);
                    $results.html('<p>' + hpcf_admin.strings.import_error + '</p>')
                           .removeClass('success').addClass('error').show();
                }
            });
        });
    }

})(jQuery);
