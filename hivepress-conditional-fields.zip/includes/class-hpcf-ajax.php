<?php
/**
 * AJAX Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class HPCF_Ajax {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Admin AJAX
        add_action('wp_ajax_hpcf_import_csv', array($this, 'import_csv'));
        add_action('wp_ajax_hpcf_export_csv', array($this, 'export_csv'));
        add_action('wp_ajax_hpcf_bulk_delete', array($this, 'bulk_delete'));
        add_action('wp_ajax_hpcf_get_parent_values', array($this, 'get_parent_values'));
        
        // Frontend AJAX (for both logged in and non-logged in users)
        add_action('wp_ajax_hpcf_get_child_values', array($this, 'get_child_values'));
        add_action('wp_ajax_nopriv_hpcf_get_child_values', array($this, 'get_child_values'));
        
        add_action('wp_ajax_hpcf_search_values', array($this, 'search_values'));
        add_action('wp_ajax_nopriv_hpcf_search_values', array($this, 'search_values'));
    }

    /**
     * Import CSV
     */
    public function import_csv() {
        check_ajax_referer('hpcf_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'hivepress-conditional-fields')));
        }

        if (!isset($_FILES['csv_file']) || !isset($_POST['pair_id'])) {
            wp_send_json_error(array('message' => __('Missing required data', 'hivepress-conditional-fields')));
        }

        $pair_id = intval($_POST['pair_id']);
        $clear_existing = isset($_POST['clear_existing']) && $_POST['clear_existing'] === 'true';
        
        global $wpdb;
        $table = $wpdb->prefix . 'hpcf_conditional_data';

        // Clear existing data if requested
        if ($clear_existing) {
            $wpdb->delete($table, array('pair_id' => $pair_id));
        }

        $file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file, 'r');
        
        if ($handle === false) {
            wp_send_json_error(array('message' => __('Could not open file', 'hivepress-conditional-fields')));
        }

        $imported = 0;
        $skipped = 0;
        $errors = array();
        $line_number = 0;

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            $line_number++;
            
            // Skip empty lines
            if (empty($data) || (count($data) === 1 && empty($data[0]))) {
                continue;
            }

            // Validate row has at least 2 columns
            if (count($data) < 2) {
                $errors[] = sprintf(__('Line %d: Invalid format (need parent_value, child_value)', 'hivepress-conditional-fields'), $line_number);
                $skipped++;
                continue;
            }

            $parent_value = sanitize_text_field(trim($data[0]));
            $child_value = sanitize_text_field(trim($data[1]));

            if (empty($parent_value) || empty($child_value)) {
                $skipped++;
                continue;
            }

            // Check for duplicates
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table WHERE pair_id = %d AND parent_value = %s AND child_value = %s",
                $pair_id, $parent_value, $child_value
            ));

            if ($exists) {
                $skipped++;
                continue;
            }

            $result = $wpdb->insert($table, array(
                'pair_id' => $pair_id,
                'parent_value' => $parent_value,
                'child_value' => $child_value,
                'sort_order' => 0
            ));

            if ($result) {
                $imported++;
            } else {
                $errors[] = sprintf(__('Line %d: Database error', 'hivepress-conditional-fields'), $line_number);
            }
        }

        fclose($handle);

        wp_send_json_success(array(
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => array_slice($errors, 0, 10), // Show first 10 errors only
            'message' => sprintf(
                __('Import completed: %d imported, %d skipped', 'hivepress-conditional-fields'),
                $imported, $skipped
            )
        ));
    }

    /**
     * Export CSV
     */
    public function export_csv() {
        check_ajax_referer('hpcf_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied', 'hivepress-conditional-fields'));
        }

        $pair_id = isset($_GET['pair_id']) ? intval($_GET['pair_id']) : 0;
        
        global $wpdb;
        
        $pair = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hpcf_field_pairs WHERE id = %d",
            $pair_id
        ));

        if (!$pair) {
            wp_die(__('Field pair not found', 'hivepress-conditional-fields'));
        }

        $data = $wpdb->get_results($wpdb->prepare(
            "SELECT parent_value, child_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC, child_value ASC",
            $pair_id
        ), ARRAY_A);

        $filename = sanitize_file_name($pair->pair_name) . '_export_' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        
        // Add BOM for Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        foreach ($data as $row) {
            fputcsv($output, array($row['parent_value'], $row['child_value']));
        }

        fclose($output);
        exit;
    }

    /**
     * Bulk delete
     */
    public function bulk_delete() {
        check_ajax_referer('hpcf_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'hivepress-conditional-fields')));
        }

        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();

        if (empty($ids)) {
            wp_send_json_error(array('message' => __('No items selected', 'hivepress-conditional-fields')));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hpcf_conditional_data';

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE id IN ($placeholders)",
            $ids
        ));

        wp_send_json_success(array(
            'deleted' => $deleted,
            'message' => sprintf(__('%d items deleted', 'hivepress-conditional-fields'), $deleted)
        ));
    }

    /**
     * Get parent values for a field pair (admin)
     */
    public function get_parent_values() {
        check_ajax_referer('hpcf_admin_nonce', 'nonce');

        $pair_id = isset($_POST['pair_id']) ? intval($_POST['pair_id']) : 0;
        
        global $wpdb;
        
        $values = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT parent_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC",
            $pair_id
        ));

        wp_send_json_success(array('values' => $values));
    }

    /**
     * Get child values based on parent selection (frontend)
     */
    public function get_child_values() {
        $pair_id = isset($_POST['pair_id']) ? intval($_POST['pair_id']) : 0;
        $parent_value = isset($_POST['parent_value']) ? sanitize_text_field($_POST['parent_value']) : '';
        
        global $wpdb;
        
        // Get child values for this parent
        $values = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT child_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d AND parent_value = %s ORDER BY sort_order ASC, child_value ASC",
            $pair_id, $parent_value
        ));

        // Debug: Log the query and results
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('HPCF get_child_values - pair_id: ' . $pair_id . ', parent_value: ' . $parent_value);
            error_log('HPCF get_child_values - found: ' . count($values) . ' values');
            error_log('HPCF last query: ' . $wpdb->last_query);
        }

        wp_send_json_success(array(
            'values' => $values,
            'pair_id' => $pair_id,
            'parent_value' => $parent_value,
            'count' => count($values)
        ));
    }

    /**
     * Search values (for autocomplete with large datasets)
     */
    public function search_values() {
        $pair_id = isset($_POST['pair_id']) ? intval($_POST['pair_id']) : 0;
        $field_type = isset($_POST['field_type']) ? sanitize_text_field($_POST['field_type']) : 'parent';
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        $parent_value = isset($_POST['parent_value']) ? sanitize_text_field($_POST['parent_value']) : '';
        
        global $wpdb;
        
        if ($field_type === 'parent') {
            $values = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT parent_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d AND parent_value LIKE %s ORDER BY parent_value ASC LIMIT 50",
                $pair_id, '%' . $wpdb->esc_like($search) . '%'
            ));
        } else {
            $where = $wpdb->prepare("pair_id = %d", $pair_id);
            if (!empty($parent_value)) {
                $where .= $wpdb->prepare(" AND parent_value = %s", $parent_value);
            }
            $where .= $wpdb->prepare(" AND child_value LIKE %s", '%' . $wpdb->esc_like($search) . '%');
            
            $values = $wpdb->get_col(
                "SELECT DISTINCT child_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE $where ORDER BY child_value ASC LIMIT 50"
            );
        }

        wp_send_json_success(array('values' => $values));
    }
}
