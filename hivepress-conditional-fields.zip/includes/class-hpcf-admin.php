<?php
/**
 * Admin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class HPCF_Admin {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'handle_form_submissions'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Conditional Fields', 'hivepress-conditional-fields'),
            __('Conditional Fields', 'hivepress-conditional-fields'),
            'manage_options',
            'hpcf-settings',
            array($this, 'render_settings_page'),
            'dashicons-category',
            30
        );

        add_submenu_page(
            'hpcf-settings',
            __('Field Pairs', 'hivepress-conditional-fields'),
            __('Field Pairs', 'hivepress-conditional-fields'),
            'manage_options',
            'hpcf-settings',
            array($this, 'render_settings_page')
        );

        add_submenu_page(
            'hpcf-settings',
            __('Manage Data', 'hivepress-conditional-fields'),
            __('Manage Data', 'hivepress-conditional-fields'),
            'manage_options',
            'hpcf-data',
            array($this, 'render_data_page')
        );

        add_submenu_page(
            'hpcf-settings',
            __('Import/Export', 'hivepress-conditional-fields'),
            __('Import/Export', 'hivepress-conditional-fields'),
            'manage_options',
            'hpcf-import',
            array($this, 'render_import_page')
        );

        add_submenu_page(
            'hpcf-settings',
            __('Settings', 'hivepress-conditional-fields'),
            __('Settings', 'hivepress-conditional-fields'),
            'manage_options',
            'hpcf-global-settings',
            array($this, 'render_global_settings_page')
        );
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'hpcf') === false) {
            return;
        }

        wp_enqueue_style('hpcf-admin', HPCF_PLUGIN_URL . 'assets/css/admin.css', array(), HPCF_VERSION);
        wp_enqueue_script('hpcf-admin', HPCF_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), HPCF_VERSION, true);
        
        wp_localize_script('hpcf-admin', 'hpcf_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hpcf_admin_nonce'),
            'strings' => array(
                'confirm_delete' => __('Are you sure you want to delete this?', 'hivepress-conditional-fields'),
                'importing' => __('Importing...', 'hivepress-conditional-fields'),
                'import_success' => __('Import completed successfully!', 'hivepress-conditional-fields'),
                'import_error' => __('Import failed. Please check your file.', 'hivepress-conditional-fields')
            )
        ));
    }

    /**
     * Handle form submissions
     */
    public function handle_form_submissions() {
        // Handle field pair creation/update
        if (isset($_POST['hpcf_save_pair']) && wp_verify_nonce($_POST['hpcf_nonce'], 'hpcf_save_pair')) {
            $this->save_field_pair();
        }

        // Handle field pair deletion
        if (isset($_GET['action']) && $_GET['action'] === 'delete_pair' && isset($_GET['pair_id'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_pair_' . $_GET['pair_id'])) {
                $this->delete_field_pair(intval($_GET['pair_id']));
            }
        }

        // Handle data entry
        if (isset($_POST['hpcf_save_data']) && wp_verify_nonce($_POST['hpcf_nonce'], 'hpcf_save_data')) {
            $this->save_conditional_data();
        }

        // Handle data deletion
        if (isset($_GET['action']) && $_GET['action'] === 'delete_data' && isset($_GET['data_id'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_data_' . $_GET['data_id'])) {
                $this->delete_conditional_data(intval($_GET['data_id']));
            }
        }

        // Handle global settings
        if (isset($_POST['hpcf_save_global_settings']) && wp_verify_nonce($_POST['hpcf_nonce'], 'hpcf_global_settings')) {
            $this->save_global_settings();
        }
    }

    /**
     * Save field pair
     */
    private function save_field_pair() {
        global $wpdb;
        $table = $wpdb->prefix . 'hpcf_field_pairs';

        $data = array(
            'pair_name' => sanitize_text_field($_POST['pair_name']),
            'parent_field_name' => sanitize_key($_POST['parent_field_name']),
            'parent_field_label' => sanitize_text_field($_POST['parent_field_label']),
            'child_field_name' => sanitize_key($_POST['child_field_name']),
            'child_field_label' => sanitize_text_field($_POST['child_field_label']),
            'block_display' => sanitize_text_field($_POST['block_display']),
            'page_display' => sanitize_text_field($_POST['page_display']),
            'search_enabled' => isset($_POST['search_enabled']) ? 1 : 0,
            'filter_enabled' => isset($_POST['filter_enabled']) ? 1 : 0,
            'status' => isset($_POST['status']) ? 1 : 0
        );

        if (!empty($_POST['pair_id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['pair_id'])));
            $message = 'pair_updated';
        } else {
            $wpdb->insert($table, $data);
            $message = 'pair_created';
        }

        wp_redirect(admin_url('admin.php?page=hpcf-settings&message=' . $message));
        exit;
    }

    /**
     * Delete field pair
     */
    private function delete_field_pair($pair_id) {
        global $wpdb;
        
        // Delete associated data first
        $wpdb->delete($wpdb->prefix . 'hpcf_conditional_data', array('pair_id' => $pair_id));
        
        // Delete the pair
        $wpdb->delete($wpdb->prefix . 'hpcf_field_pairs', array('id' => $pair_id));

        wp_redirect(admin_url('admin.php?page=hpcf-settings&message=pair_deleted'));
        exit;
    }

    /**
     * Save conditional data
     */
    private function save_conditional_data() {
        global $wpdb;
        $table = $wpdb->prefix . 'hpcf_conditional_data';

        $data = array(
            'pair_id' => intval($_POST['pair_id']),
            'parent_value' => sanitize_text_field($_POST['parent_value']),
            'child_value' => sanitize_text_field($_POST['child_value']),
            'sort_order' => intval($_POST['sort_order'])
        );

        if (!empty($_POST['data_id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['data_id'])));
            $message = 'data_updated';
        } else {
            $wpdb->insert($table, $data);
            $message = 'data_created';
        }

        wp_redirect(admin_url('admin.php?page=hpcf-data&pair_id=' . $data['pair_id'] . '&message=' . $message));
        exit;
    }

    /**
     * Delete conditional data
     */
    private function delete_conditional_data($data_id) {
        global $wpdb;
        
        $data = $wpdb->get_row($wpdb->prepare(
            "SELECT pair_id FROM {$wpdb->prefix}hpcf_conditional_data WHERE id = %d",
            $data_id
        ));
        
        $wpdb->delete($wpdb->prefix . 'hpcf_conditional_data', array('id' => $data_id));

        $redirect_url = admin_url('admin.php?page=hpcf-data&message=data_deleted');
        if ($data) {
            $redirect_url .= '&pair_id=' . $data->pair_id;
        }
        
        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Save global settings
     */
    private function save_global_settings() {
        $settings = array(
            'enable_search' => isset($_POST['enable_search']),
            'enable_filter' => isset($_POST['enable_filter']),
            'ajax_threshold' => intval($_POST['ajax_threshold'])
        );

        update_option('hpcf_settings', $settings);

        wp_redirect(admin_url('admin.php?page=hpcf-global-settings&message=settings_saved'));
        exit;
    }

    /**
     * Render settings page (Field Pairs)
     */
    public function render_settings_page() {
        global $wpdb;
        
        $edit_pair = null;
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['pair_id'])) {
            $edit_pair = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}hpcf_field_pairs WHERE id = %d",
                intval($_GET['pair_id'])
            ));
        }

        $pairs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hpcf_field_pairs ORDER BY created_at DESC");

        include HPCF_PLUGIN_DIR . 'templates/admin/settings-page.php';
    }

    /**
     * Render data management page
     */
    public function render_data_page() {
        global $wpdb;
        
        $pairs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hpcf_field_pairs WHERE status = 1 ORDER BY pair_name ASC");
        
        $selected_pair = isset($_GET['pair_id']) ? intval($_GET['pair_id']) : (count($pairs) > 0 ? $pairs[0]->id : 0);
        
        $edit_data = null;
        if (isset($_GET['action']) && $_GET['action'] === 'edit_data' && isset($_GET['data_id'])) {
            $edit_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}hpcf_conditional_data WHERE id = %d",
                intval($_GET['data_id'])
            ));
        }

        // Get data with pagination
        $per_page = 50;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // Search functionality
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
        
        $where = $wpdb->prepare("WHERE pair_id = %d", $selected_pair);
        if (!empty($search)) {
            $where .= $wpdb->prepare(" AND (parent_value LIKE %s OR child_value LIKE %s)", '%' . $wpdb->esc_like($search) . '%', '%' . $wpdb->esc_like($search) . '%');
        }
        
        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hpcf_conditional_data $where");
        $total_pages = ceil($total_items / $per_page);
        
        $data_items = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}hpcf_conditional_data $where ORDER BY parent_value ASC, sort_order ASC LIMIT $offset, $per_page"
        );

        // Get unique parent values for the selected pair
        $parent_values = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT parent_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC",
            $selected_pair
        ));

        include HPCF_PLUGIN_DIR . 'templates/admin/data-page.php';
    }

    /**
     * Render import/export page
     */
    public function render_import_page() {
        global $wpdb;
        
        $pairs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}hpcf_field_pairs WHERE status = 1 ORDER BY pair_name ASC");

        include HPCF_PLUGIN_DIR . 'templates/admin/import-page.php';
    }

    /**
     * Render global settings page
     */
    public function render_global_settings_page() {
        $settings = get_option('hpcf_settings', array(
            'enable_search' => true,
            'enable_filter' => true,
            'ajax_threshold' => 50
        ));

        include HPCF_PLUGIN_DIR . 'templates/admin/global-settings-page.php';
    }
}
