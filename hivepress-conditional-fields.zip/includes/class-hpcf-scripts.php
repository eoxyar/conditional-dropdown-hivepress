<?php
/**
 * Scripts Handler - Pass data inline like the reference plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class HPCF_Scripts {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Enqueue frontend scripts - pass data inline like reference plugin
     */
    public function enqueue_frontend_scripts() {
        wp_enqueue_script(
            'hpcf-conditional-selector',
            HPCF_PLUGIN_URL . 'assets/js/conditional-selector.js',
            array('jquery'),
            HPCF_VERSION,
            true
        );

        // Get all field pairs and their data
        $pairs = HPCF_Fields::get_field_pairs();
        $all_data = array();
        
        foreach ($pairs as $pair) {
            $data = HPCF_Fields::get_conditional_data($pair->id);
            $all_data[$pair->parent_field_name] = array(
                'parent_field' => $pair->parent_field_name,
                'child_field' => $pair->child_field_name,
                'data' => $data,
            );
        }
        
        // Pass data inline like the working reference
        wp_add_inline_script(
            'hpcf-conditional-selector',
            'window.hpcfConditionalData = ' . json_encode($all_data) . ';'
        );
        
        wp_enqueue_style('hpcf-frontend', HPCF_PLUGIN_URL . 'assets/css/frontend.css', array(), HPCF_VERSION);
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        // Admin pages
        if (strpos($hook, 'hpcf') !== false) {
            wp_enqueue_style('hpcf-admin', HPCF_PLUGIN_URL . 'assets/css/admin.css', array(), HPCF_VERSION);
            wp_enqueue_script('hpcf-admin', HPCF_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), HPCF_VERSION, true);
            
            wp_localize_script('hpcf-admin', 'hpcf_admin', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('hpcf_admin_nonce'),
                'strings' => array(
                    'confirm_delete' => __('Are you sure you want to delete this?', 'hivepress-conditional-fields'),
                    'importing' => __('Importing...', 'hivepress-conditional-fields'),
                    'import_success' => __('Import completed successfully!', 'hivepress-conditional-fields'),
                    'import_error' => __('Import failed. Please check your file.', 'hivepress-conditional-fields')
                )
            ));
        }
        
        // Listing edit page in admin
        global $post_type;
        if (($hook === 'post.php' || $hook === 'post-new.php') && $post_type === 'hp_listing') {
            wp_enqueue_script(
                'hpcf-admin-listing',
                HPCF_PLUGIN_URL . 'assets/js/admin-listing.js',
                array('jquery'),
                HPCF_VERSION,
                true
            );
            
            // Pass data inline for admin too
            $pairs = HPCF_Fields::get_field_pairs();
            $all_data = array();
            
            foreach ($pairs as $pair) {
                $data = HPCF_Fields::get_conditional_data($pair->id);
                $all_data[$pair->parent_field_name] = array(
                    'parent_field' => $pair->parent_field_name,
                    'child_field' => $pair->child_field_name,
                    'data' => $data,
                );
            }
            
            wp_add_inline_script(
                'hpcf-admin-listing',
                'window.hpcfConditionalData = ' . json_encode($all_data) . ';'
            );
        }
    }
}
