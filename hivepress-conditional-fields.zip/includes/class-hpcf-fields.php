<?php
/**
 * HivePress Fields Integration - Following HivePress structure
 */

if (!defined('ABSPATH')) {
    exit;
}

class HPCF_Fields {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Add fields to submit form
        add_filter('hivepress/v1/forms/listing_submit', array($this, 'add_form_fields'), 100);
        
        // Add attributes to listing model (for edit, display, search, filter)
        add_filter('hivepress/v1/models/listing/attributes', array($this, 'add_listing_attributes'), 1000);
    }

    /**
     * Get conditional data structured as parent => [children]
     */
    public static function get_conditional_data($pair_id) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT parent_value, child_value FROM {$wpdb->prefix}hpcf_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC, sort_order ASC, child_value ASC",
            $pair_id
        ));
        
        $data = array();
        foreach ($results as $row) {
            if (!isset($data[$row->parent_value])) {
                $data[$row->parent_value] = array();
            }
            $data[$row->parent_value][$row->child_value] = true;
        }
        
        return $data;
    }

    /**
     * Get all field pairs
     */
    public static function get_field_pairs() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'hpcf_field_pairs';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return array();
        }
        
        return $wpdb->get_results("SELECT * FROM {$table} WHERE status = 1");
    }

    /**
     * Add fields to submit form
     */
   public function add_form_fields($form) {
    $pairs = self::get_field_pairs();

    $pair_index = 0;

    foreach ($pairs as $pair) {
        $data = self::get_conditional_data($pair->id);

        // Base order for this pair
        $base_order = isset($pair->sort_order)
            ? intval($pair->sort_order)
            : ($pair_index * 10 + 10);

        $parent_order = $base_order;
        $child_order  = $base_order + 1;

        // Get parent options
        $parent_options = array_keys($data);

        // Get all child options
        $child_options = array();
        foreach ($data as $parent => $children) {
            foreach ($children as $child => $_) {
                $child_options[$child] = $child;
            }
        }

        // Parent field
        $form['fields'][$pair->parent_field_name] = array(
            'type' => 'select',
            'label' => $pair->parent_field_label,
            'options' => array_combine($parent_options, $parent_options),
            'required' => true,
            '_order' => $parent_order,
        );

        // Child field (always immediately after parent)
        $form['fields'][$pair->child_field_name] = array(
            'type' => 'select',
            'label' => $pair->child_field_label,
            'options' => $child_options,
            'required' => true,
            '_order' => $child_order,
        );

        $pair_index++;
    }

    return $form;
}

    /**
     * Add listing attributes - following exact HivePress structure
     */
    public function add_listing_attributes($attributes) {
        $pairs = self::get_field_pairs();
        
        $pair_index = 0;
        foreach ($pairs as $pair) {
            $data = self::get_conditional_data($pair->id);
            
            $enable_search_filter = (bool) $pair->search_enabled;
            
            // Calculate order - each pair gets consecutive numbers
            // Use pair's sort_order if set, otherwise use index
            $base_order = isset($pair->sort_order) ? intval($pair->sort_order) : ($pair_index * 10 + 10);
            $parent_order = $base_order;
            $child_order = $base_order + 1;
            
            // Build parent options
            $parent_options = array('' => '');
            foreach (array_keys($data) as $parent) {
                $parent_options[$parent] = $parent;
            }
            
            // Build child options (all values)
            $child_options = array('' => '');
            foreach ($data as $parent => $children) {
                foreach ($children as $child => $_) {
                    $child_options[$child] = $child;
                }
            }
            
            // Build display areas for parent
            $parent_display_areas = array();
            if ($pair->block_display && $pair->block_display !== 'hide') {
                $parent_display_areas[] = 'view_block_' . $pair->block_display;
            }
            if ($pair->page_display && $pair->page_display !== 'hide') {
                $parent_display_areas[] = 'view_page_' . $pair->page_display;
            }
            
            // Build display areas for child
            $child_display_areas = array();
            if ($pair->block_display && $pair->block_display !== 'hide') {
                $child_display_areas[] = 'view_block_' . $pair->block_display;
            }
            if ($pair->page_display && $pair->page_display !== 'hide') {
                $child_display_areas[] = 'view_page_' . $pair->page_display;
            }
            
            // Parent attribute
            $attributes[$pair->parent_field_name] = array(
                'label' => $pair->parent_field_label,
                'type' => 'select',
                'editable' => true,
                'searchable' => $enable_search_filter,
                'filterable' => $enable_search_filter,
                'indexable' => true,
                'display_areas' => $parent_display_areas,
                'options' => $parent_options,
                
                'edit_field' => array(
                    'label' => $pair->parent_field_label,
                    'type' => 'select',
                    'source' => array(),
                    '_external' => true,
                    '_order' => $parent_order,
                    'options' => $parent_options,
                    'required' => true,
                ),
                
                'search_field' => array(
                    'label' => $pair->parent_field_label,
                    'type' => 'select',
                    'options' => $parent_options,
                    '_external' => true,
                    '_order' => $parent_order,
                ),
            );
            
            // Child attribute
            $attributes[$pair->child_field_name] = array(
                'label' => $pair->child_field_label,
                'type' => 'select',
                'editable' => true,
                'searchable' => $enable_search_filter,
                'filterable' => $enable_search_filter,
                'indexable' => true,
                'display_areas' => $child_display_areas,
                'options' => $child_options,
                
                'edit_field' => array(
                    'label' => $pair->child_field_label,
                    'type' => 'select',
                    'source' => array(),
                    '_external' => true,
                    '_order' => $child_order,
                    'options' => $child_options,
                    'required' => true,
                ),
                
                'search_field' => array(
                    'label' => $pair->child_field_label,
                    'type' => 'select',
                    'options' => $child_options,
                    '_external' => true,
                    '_order' => $child_order,
                ),
            );
            
            $pair_index++;
        }
        
        return $attributes;
    }
}
