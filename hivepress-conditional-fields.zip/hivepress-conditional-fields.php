<?php
/**
 * Plugin Name: HivePress Conditional Fields
 * Plugin URI: https://hivepress.io/
 * Description: Adds conditional parent-child dropdown fields to HivePress listings with CSV import support and configurable display areas.
 * Version: 1.1.0
 * Author: HivePress
 * Author URI: https://hivepress.io/
 * Text Domain: hivepress-conditional-fields
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HPCF_VERSION', '1.1.0');
define('HPCF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HPCF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('HPCF_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
final class HivePress_Conditional_Fields {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('plugins_loaded', array($this, 'load_plugin'), 20);
    }

    /**
     * Plugin activation - create database tables
     */
    public function activate() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $table_pairs = $wpdb->prefix . 'hpcf_field_pairs';
        $sql_pairs = "CREATE TABLE $table_pairs (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            pair_name varchar(100) NOT NULL,
            parent_field_name varchar(100) NOT NULL,
            parent_field_label varchar(255) NOT NULL,
            child_field_name varchar(100) NOT NULL,
            child_field_label varchar(255) NOT NULL,
            block_display varchar(50) DEFAULT 'primary',
            page_display varchar(50) DEFAULT 'primary',
            search_enabled tinyint(1) DEFAULT 1,
            filter_enabled tinyint(1) DEFAULT 1,
            status tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY pair_name (pair_name)
        ) $charset_collate;";
        
        $table_data = $wpdb->prefix . 'hpcf_conditional_data';
        $sql_data = "CREATE TABLE $table_data (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            pair_id mediumint(9) NOT NULL,
            parent_value varchar(255) NOT NULL,
            child_value varchar(255) NOT NULL,
            sort_order int(11) DEFAULT 0,
            PRIMARY KEY (id),
            KEY pair_id (pair_id),
            KEY parent_value (parent_value)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_pairs);
        dbDelta($sql_data);
        
        add_option('hpcf_settings', array(
            'enable_search' => true,
            'enable_filter' => true,
        ));
        
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Load plugin files
     */
    public function load_plugin() {
        require_once HPCF_PLUGIN_DIR . 'includes/class-hpcf-admin.php';
        require_once HPCF_PLUGIN_DIR . 'includes/class-hpcf-ajax.php';
        require_once HPCF_PLUGIN_DIR . 'includes/class-hpcf-fields.php';
        require_once HPCF_PLUGIN_DIR . 'includes/class-hpcf-scripts.php';
        
        HPCF_Admin::instance();
        HPCF_Ajax::instance();
        HPCF_Fields::instance();
        HPCF_Scripts::instance();
        
        load_plugin_textdomain('hivepress-conditional-fields', false, dirname(HPCF_PLUGIN_BASENAME) . '/languages');
    }
}

function HPCF() {
    return HivePress_Conditional_Fields::instance();
}

HPCF();
