<?php
/**
 * Settings Page Template - Field Pairs Management
 */
if (!defined('ABSPATH')) {
    exit;
}

$block_display_options = array(
    'primary' => __('Primary', 'hivepress-conditional-fields'),
    'secondary' => __('Secondary', 'hivepress-conditional-fields'),
    'ternary' => __('Ternary', 'hivepress-conditional-fields'),
    'hide' => __('Hide', 'hivepress-conditional-fields'),
);

$page_display_options = array(
    'primary' => __('Primary', 'hivepress-conditional-fields'),
    'secondary' => __('Secondary', 'hivepress-conditional-fields'),
    'ternary' => __('Ternary', 'hivepress-conditional-fields'),
    'hide' => __('Hide', 'hivepress-conditional-fields'),
);
?>
<div class="wrap hpcf-admin-wrap">
    <h1 class="wp-heading-inline">
        <span class="dashicons dashicons-category"></span>
        <?php esc_html_e('HivePress Conditional Fields', 'hivepress-conditional-fields'); ?>
    </h1>
    
    <?php if (isset($_GET['message'])): ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php
                $messages = array(
                    'pair_created' => __('Field pair created successfully!', 'hivepress-conditional-fields'),
                    'pair_updated' => __('Field pair updated successfully!', 'hivepress-conditional-fields'),
                    'pair_deleted' => __('Field pair deleted successfully!', 'hivepress-conditional-fields'),
                );
                echo esc_html($messages[$_GET['message']] ?? '');
                ?>
            </p>
        </div>
    <?php endif; ?>

    <div class="hpcf-admin-container">
        <!-- Field Pair Form -->
        <div class="hpcf-form-section">
            <h2>
                <?php echo $edit_pair ? esc_html__('Edit Field Pair', 'hivepress-conditional-fields') : esc_html__('Add New Field Pair', 'hivepress-conditional-fields'); ?>
            </h2>
            
            <form method="post" action="" class="hpcf-form">
                <?php wp_nonce_field('hpcf_save_pair', 'hpcf_nonce'); ?>
                
                <?php if ($edit_pair): ?>
                    <input type="hidden" name="pair_id" value="<?php echo esc_attr($edit_pair->id); ?>">
                <?php endif; ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="pair_name"><?php esc_html_e('Pair Name', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="pair_name" 
                                   name="pair_name" 
                                   class="regular-text" 
                                   value="<?php echo $edit_pair ? esc_attr($edit_pair->pair_name) : ''; ?>"
                                   placeholder="<?php esc_attr_e('e.g., car_make_model', 'hivepress-conditional-fields'); ?>"
                                   required>
                            <p class="description"><?php esc_html_e('Unique identifier for this field pair', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row" colspan="2">
                            <h3><?php esc_html_e('Parent Field (e.g., Car Make, Country)', 'hivepress-conditional-fields'); ?></h3>
                        </th>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="parent_field_name"><?php esc_html_e('Field Name', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="parent_field_name" 
                                   name="parent_field_name" 
                                   class="regular-text" 
                                   value="<?php echo $edit_pair ? esc_attr($edit_pair->parent_field_name) : ''; ?>"
                                   placeholder="<?php esc_attr_e('car_make', 'hivepress-conditional-fields'); ?>"
                                   pattern="[a-z_]+"
                                   required>
                            <p class="description"><?php esc_html_e('Lowercase with underscores only (e.g., car_make)', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="parent_field_label"><?php esc_html_e('Field Label', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="parent_field_label" 
                                   name="parent_field_label" 
                                   class="regular-text" 
                                   value="<?php echo $edit_pair ? esc_attr($edit_pair->parent_field_label) : ''; ?>"
                                   placeholder="<?php esc_attr_e('Car Make', 'hivepress-conditional-fields'); ?>"
                                   required>
                            <p class="description"><?php esc_html_e('Display label shown to users', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row" colspan="2">
                            <h3><?php esc_html_e('Child Field (e.g., Car Model, City)', 'hivepress-conditional-fields'); ?></h3>
                        </th>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="child_field_name"><?php esc_html_e('Field Name', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="child_field_name" 
                                   name="child_field_name" 
                                   class="regular-text" 
                                   value="<?php echo $edit_pair ? esc_attr($edit_pair->child_field_name) : ''; ?>"
                                   placeholder="<?php esc_attr_e('car_model', 'hivepress-conditional-fields'); ?>"
                                   pattern="[a-z_]+"
                                   required>
                            <p class="description"><?php esc_html_e('Lowercase with underscores only (e.g., car_model)', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="child_field_label"><?php esc_html_e('Field Label', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="child_field_label" 
                                   name="child_field_label" 
                                   class="regular-text" 
                                   value="<?php echo $edit_pair ? esc_attr($edit_pair->child_field_label) : ''; ?>"
                                   placeholder="<?php esc_attr_e('Car Model', 'hivepress-conditional-fields'); ?>"
                                   required>
                            <p class="description"><?php esc_html_e('Display label shown to users', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row" colspan="2">
                            <h3><?php esc_html_e('Display Settings', 'hivepress-conditional-fields'); ?></h3>
                        </th>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="block_display"><?php esc_html_e('Block Display', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <select id="block_display" name="block_display" class="regular-text">
                                <?php foreach ($block_display_options as $value => $label): ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($edit_pair ? $edit_pair->block_display : 'primary', $value); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Display position in listing blocks/cards', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="page_display"><?php esc_html_e('Page Display', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <select id="page_display" name="page_display" class="regular-text">
                                <?php foreach ($page_display_options as $value => $label): ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($edit_pair ? $edit_pair->page_display : 'primary', $value); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Display position on listing detail page', 'hivepress-conditional-fields'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php esc_html_e('Options', 'hivepress-conditional-fields'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="search_enabled" value="1" <?php checked($edit_pair ? $edit_pair->search_enabled : 1, 1); ?>>
                                <?php esc_html_e('Enable search functionality', 'hivepress-conditional-fields'); ?>
                            </label>
                            <br><br>
                            <label>
                                <input type="checkbox" name="filter_enabled" value="1" <?php checked($edit_pair ? $edit_pair->filter_enabled : 1, 1); ?>>
                                <?php esc_html_e('Enable filter functionality', 'hivepress-conditional-fields'); ?>
                            </label>
                            <br><br>
                            <label>
                                <input type="checkbox" name="status" value="1" <?php checked($edit_pair ? $edit_pair->status : 1, 1); ?>>
                                <?php esc_html_e('Active', 'hivepress-conditional-fields'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="hpcf_save_pair" class="button button-primary">
                        <?php echo $edit_pair ? esc_html__('Update Field Pair', 'hivepress-conditional-fields') : esc_html__('Create Field Pair', 'hivepress-conditional-fields'); ?>
                    </button>
                    <?php if ($edit_pair): ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-settings')); ?>" class="button">
                            <?php esc_html_e('Cancel', 'hivepress-conditional-fields'); ?>
                        </a>
                    <?php endif; ?>
                </p>
            </form>
        </div>

        <!-- Existing Field Pairs List -->
        <div class="hpcf-list-section">
            <h2><?php esc_html_e('Existing Field Pairs', 'hivepress-conditional-fields'); ?></h2>
            
            <?php if (empty($pairs)): ?>
                <div class="hpcf-empty-state">
                    <span class="dashicons dashicons-info"></span>
                    <p><?php esc_html_e('No field pairs created yet. Create your first one above!', 'hivepress-conditional-fields'); ?></p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Pair Name', 'hivepress-conditional-fields'); ?></th>
                            <th><?php esc_html_e('Parent Field', 'hivepress-conditional-fields'); ?></th>
                            <th><?php esc_html_e('Child Field', 'hivepress-conditional-fields'); ?></th>
                            <th><?php esc_html_e('Display', 'hivepress-conditional-fields'); ?></th>
                            <th><?php esc_html_e('Status', 'hivepress-conditional-fields'); ?></th>
                            <th><?php esc_html_e('Actions', 'hivepress-conditional-fields'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pairs as $pair): ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($pair->pair_name); ?></strong>
                                </td>
                                <td>
                                    <code><?php echo esc_html($pair->parent_field_name); ?></code>
                                    <br>
                                    <small><?php echo esc_html($pair->parent_field_label); ?></small>
                                </td>
                                <td>
                                    <code><?php echo esc_html($pair->child_field_name); ?></code>
                                    <br>
                                    <small><?php echo esc_html($pair->child_field_label); ?></small>
                                </td>
                                <td>
                                    <small>Block: <?php echo esc_html($pair->block_display ?? 'primary'); ?></small><br>
                                    <small>Page: <?php echo esc_html($pair->page_display ?? 'primary'); ?></small>
                                </td>
                                <td>
                                    <?php if ($pair->status): ?>
                                        <span class="hpcf-status hpcf-status-active"><?php esc_html_e('Active', 'hivepress-conditional-fields'); ?></span>
                                    <?php else: ?>
                                        <span class="hpcf-status hpcf-status-inactive"><?php esc_html_e('Inactive', 'hivepress-conditional-fields'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-data&pair_id=' . $pair->id)); ?>" class="button button-small">
                                        <?php esc_html_e('Manage Data', 'hivepress-conditional-fields'); ?>
                                    </a>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-settings&action=edit&pair_id=' . $pair->id)); ?>" class="button button-small">
                                        <?php esc_html_e('Edit', 'hivepress-conditional-fields'); ?>
                                    </a>
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=hpcf-settings&action=delete_pair&pair_id=' . $pair->id), 'delete_pair_' . $pair->id)); ?>" 
                                       class="button button-small button-link-delete" 
                                       onclick="return confirm('<?php esc_attr_e('Are you sure? This will delete all associated data.', 'hivepress-conditional-fields'); ?>');">
                                        <?php esc_html_e('Delete', 'hivepress-conditional-fields'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
