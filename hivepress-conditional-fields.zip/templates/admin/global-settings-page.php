<?php
/**
 * Global Settings Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap hpcf-admin-wrap">
    <h1 class="wp-heading-inline">
        <span class="dashicons dashicons-admin-settings"></span>
        <?php esc_html_e('Global Settings', 'hivepress-conditional-fields'); ?>
    </h1>
    
    <?php if (isset($_GET['message']) && $_GET['message'] === 'settings_saved'): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('Settings saved successfully!', 'hivepress-conditional-fields'); ?></p>
        </div>
    <?php endif; ?>

    <div class="hpcf-admin-container">
        <form method="post" action="">
            <?php wp_nonce_field('hpcf_global_settings', 'hpcf_nonce'); ?>
            
            <div class="hpcf-section">
                <h2><?php esc_html_e('Search & Filter Settings', 'hivepress-conditional-fields'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Global Search', 'hivepress-conditional-fields'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_search" value="1" <?php checked(!empty($settings['enable_search']), true); ?>>
                                <?php esc_html_e('Enable search/autocomplete for dropdown fields', 'hivepress-conditional-fields'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('When enabled, users can type to search within dropdown options. Recommended for large datasets.', 'hivepress-conditional-fields'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php esc_html_e('Global Filter', 'hivepress-conditional-fields'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_filter" value="1" <?php checked(!empty($settings['enable_filter']), true); ?>>
                                <?php esc_html_e('Enable filter fields in listing search/filter forms', 'hivepress-conditional-fields'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('Individual field pairs can override this setting.', 'hivepress-conditional-fields'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="hpcf-section">
                <h2><?php esc_html_e('Performance Settings', 'hivepress-conditional-fields'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ajax_threshold"><?php esc_html_e('AJAX Threshold', 'hivepress-conditional-fields'); ?></label>
                        </th>
                        <td>
                            <input type="number" 
                                   id="ajax_threshold" 
                                   name="ajax_threshold" 
                                   value="<?php echo esc_attr($settings['ajax_threshold'] ?? 50); ?>"
                                   min="10"
                                   max="500"
                                   class="small-text">
                            <p class="description">
                                <?php esc_html_e('Load dropdown options via AJAX when there are more than this many parent values. Lower values improve page load time for large datasets.', 'hivepress-conditional-fields'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="hpcf-section">
                <h2><?php esc_html_e('Advanced Settings', 'hivepress-conditional-fields'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Uninstall Data', 'hivepress-conditional-fields'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="delete_data_on_uninstall" value="1" <?php checked(!empty($settings['delete_data_on_uninstall']), true); ?>>
                                <?php esc_html_e('Delete all plugin data when uninstalling', 'hivepress-conditional-fields'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('Warning: This will permanently delete all field pairs and conditional data when the plugin is deleted.', 'hivepress-conditional-fields'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <p class="submit">
                <button type="submit" name="hpcf_save_global_settings" class="button button-primary">
                    <?php esc_html_e('Save Settings', 'hivepress-conditional-fields'); ?>
                </button>
            </p>
        </form>
    </div>
</div>
