<?php
/**
 * Data Management Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$current_pair = null;
foreach ($pairs as $pair) {
    if ($pair->id == $selected_pair) {
        $current_pair = $pair;
        break;
    }
}
?>
<div class="wrap hpcf-admin-wrap">
    <h1 class="wp-heading-inline">
        <span class="dashicons dashicons-database"></span>
        <?php esc_html_e('Manage Conditional Data', 'hivepress-conditional-fields'); ?>
    </h1>
    
    <?php if (isset($_GET['message'])): ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php
                $messages = array(
                    'data_created' => __('Data entry created successfully!', 'hivepress-conditional-fields'),
                    'data_updated' => __('Data entry updated successfully!', 'hivepress-conditional-fields'),
                    'data_deleted' => __('Data entry deleted successfully!', 'hivepress-conditional-fields'),
                );
                echo esc_html($messages[$_GET['message']] ?? '');
                ?>
            </p>
        </div>
    <?php endif; ?>

    <?php if (empty($pairs)): ?>
        <div class="hpcf-empty-state">
            <span class="dashicons dashicons-warning"></span>
            <p><?php esc_html_e('No active field pairs found.', 'hivepress-conditional-fields'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-settings')); ?>" class="button button-primary">
                <?php esc_html_e('Create Field Pair', 'hivepress-conditional-fields'); ?>
            </a>
        </div>
    <?php else: ?>
        <div class="hpcf-admin-container">
            <!-- Pair Selector and Stats -->
            <div class="hpcf-data-header">
                <form method="get" action="" class="hpcf-pair-selector">
                    <input type="hidden" name="page" value="hpcf-data">
                    <label for="pair_id"><?php esc_html_e('Select Field Pair:', 'hivepress-conditional-fields'); ?></label>
                    <select name="pair_id" id="pair_id" onchange="this.form.submit()">
                        <?php foreach ($pairs as $pair): ?>
                            <option value="<?php echo esc_attr($pair->id); ?>" <?php selected($selected_pair, $pair->id); ?>>
                                <?php echo esc_html($pair->pair_name . ' (' . $pair->parent_field_label . ' → ' . $pair->child_field_label . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                
                <?php if ($current_pair): ?>
                    <div class="hpcf-data-stats">
                        <span class="hpcf-stat">
                            <strong><?php echo esc_html($total_items); ?></strong>
                            <?php esc_html_e('Total Entries', 'hivepress-conditional-fields'); ?>
                        </span>
                        <span class="hpcf-stat">
                            <strong><?php echo count($parent_values); ?></strong>
                            <?php echo esc_html($current_pair->parent_field_label); ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($current_pair): ?>
                <div class="hpcf-data-content">
                    <!-- Add/Edit Data Form -->
                    <div class="hpcf-form-section hpcf-form-compact">
                        <h2>
                            <?php echo $edit_data ? esc_html__('Edit Entry', 'hivepress-conditional-fields') : esc_html__('Add New Entry', 'hivepress-conditional-fields'); ?>
                        </h2>
                        
                        <form method="post" action="" class="hpcf-inline-form">
                            <?php wp_nonce_field('hpcf_save_data', 'hpcf_nonce'); ?>
                            <input type="hidden" name="pair_id" value="<?php echo esc_attr($selected_pair); ?>">
                            
                            <?php if ($edit_data): ?>
                                <input type="hidden" name="data_id" value="<?php echo esc_attr($edit_data->id); ?>">
                            <?php endif; ?>
                            
                            <div class="hpcf-inline-fields">
                                <div class="hpcf-field-group">
                                    <label for="parent_value"><?php echo esc_html($current_pair->parent_field_label); ?></label>
                                    <input type="text" 
                                           id="parent_value" 
                                           name="parent_value" 
                                           value="<?php echo $edit_data ? esc_attr($edit_data->parent_value) : ''; ?>"
                                           placeholder="<?php esc_attr_e('e.g., Toyota', 'hivepress-conditional-fields'); ?>"
                                           list="parent_values_list"
                                           required>
                                    <datalist id="parent_values_list">
                                        <?php foreach ($parent_values as $value): ?>
                                            <option value="<?php echo esc_attr($value); ?>">
                                        <?php endforeach; ?>
                                    </datalist>
                                </div>
                                
                                <div class="hpcf-field-group">
                                    <label for="child_value"><?php echo esc_html($current_pair->child_field_label); ?></label>
                                    <input type="text" 
                                           id="child_value" 
                                           name="child_value" 
                                           value="<?php echo $edit_data ? esc_attr($edit_data->child_value) : ''; ?>"
                                           placeholder="<?php esc_attr_e('e.g., Camry', 'hivepress-conditional-fields'); ?>"
                                           required>
                                </div>
                                
                                <div class="hpcf-field-group hpcf-field-small">
                                    <label for="sort_order"><?php esc_html_e('Order', 'hivepress-conditional-fields'); ?></label>
                                    <input type="number" 
                                           id="sort_order" 
                                           name="sort_order" 
                                           value="<?php echo $edit_data ? esc_attr($edit_data->sort_order) : '0'; ?>">
                                </div>
                                
                                <div class="hpcf-field-group hpcf-field-buttons">
                                    <button type="submit" name="hpcf_save_data" class="button button-primary">
                                        <?php echo $edit_data ? esc_html__('Update', 'hivepress-conditional-fields') : esc_html__('Add', 'hivepress-conditional-fields'); ?>
                                    </button>
                                    <?php if ($edit_data): ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-data&pair_id=' . $selected_pair)); ?>" class="button">
                                            <?php esc_html_e('Cancel', 'hivepress-conditional-fields'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Search and Bulk Actions -->
                    <div class="hpcf-data-toolbar">
                        <form method="get" action="" class="hpcf-search-form">
                            <input type="hidden" name="page" value="hpcf-data">
                            <input type="hidden" name="pair_id" value="<?php echo esc_attr($selected_pair); ?>">
                            <input type="text" 
                                   name="search" 
                                   value="<?php echo esc_attr($search); ?>" 
                                   placeholder="<?php esc_attr_e('Search...', 'hivepress-conditional-fields'); ?>">
                            <button type="submit" class="button"><?php esc_html_e('Search', 'hivepress-conditional-fields'); ?></button>
                            <?php if (!empty($search)): ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-data&pair_id=' . $selected_pair)); ?>" class="button">
                                    <?php esc_html_e('Clear', 'hivepress-conditional-fields'); ?>
                                </a>
                            <?php endif; ?>
                        </form>
                        
                        <div class="hpcf-bulk-actions">
                            <button type="button" id="hpcf-bulk-delete" class="button" disabled>
                                <?php esc_html_e('Delete Selected', 'hivepress-conditional-fields'); ?>
                            </button>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-import')); ?>" class="button">
                                <?php esc_html_e('Import CSV', 'hivepress-conditional-fields'); ?>
                            </a>
                        </div>
                    </div>

                    <!-- Data Table -->
                    <?php if (empty($data_items)): ?>
                        <div class="hpcf-empty-state">
                            <span class="dashicons dashicons-info"></span>
                            <p><?php esc_html_e('No data entries found. Add your first entry above or import via CSV!', 'hivepress-conditional-fields'); ?></p>
                        </div>
                    <?php else: ?>
                        <form id="hpcf-data-form">
                            <table class="wp-list-table widefat fixed striped hpcf-data-table">
                                <thead>
                                    <tr>
                                        <th class="check-column">
                                            <input type="checkbox" id="hpcf-select-all">
                                        </th>
                                        <th><?php echo esc_html($current_pair->parent_field_label); ?></th>
                                        <th><?php echo esc_html($current_pair->child_field_label); ?></th>
                                        <th><?php esc_html_e('Order', 'hivepress-conditional-fields'); ?></th>
                                        <th><?php esc_html_e('Actions', 'hivepress-conditional-fields'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($data_items as $item): ?>
                                        <tr>
                                            <td class="check-column">
                                                <input type="checkbox" class="hpcf-item-checkbox" value="<?php echo esc_attr($item->id); ?>">
                                            </td>
                                            <td>
                                                <strong><?php echo esc_html($item->parent_value); ?></strong>
                                            </td>
                                            <td>
                                                <?php echo esc_html($item->child_value); ?>
                                            </td>
                                            <td>
                                                <?php echo esc_html($item->sort_order); ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-data&pair_id=' . $selected_pair . '&action=edit_data&data_id=' . $item->id)); ?>" 
                                                   class="button button-small">
                                                    <?php esc_html_e('Edit', 'hivepress-conditional-fields'); ?>
                                                </a>
                                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=hpcf-data&pair_id=' . $selected_pair . '&action=delete_data&data_id=' . $item->id), 'delete_data_' . $item->id)); ?>" 
                                                   class="button button-small button-link-delete" 
                                                   onclick="return confirm('<?php esc_attr_e('Delete this entry?', 'hivepress-conditional-fields'); ?>');">
                                                    <?php esc_html_e('Delete', 'hivepress-conditional-fields'); ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </form>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="tablenav bottom">
                                <div class="tablenav-pages">
                                    <span class="displaying-num">
                                        <?php printf(esc_html__('%s items', 'hivepress-conditional-fields'), number_format_i18n($total_items)); ?>
                                    </span>
                                    <span class="pagination-links">
                                        <?php
                                        $base_url = admin_url('admin.php?page=hpcf-data&pair_id=' . $selected_pair);
                                        if (!empty($search)) {
                                            $base_url .= '&search=' . urlencode($search);
                                        }
                                        
                                        if ($current_page > 1) {
                                            echo '<a class="prev-page button" href="' . esc_url($base_url . '&paged=' . ($current_page - 1)) . '">‹</a>';
                                        }
                                        
                                        echo '<span class="paging-input">' . $current_page . ' / ' . $total_pages . '</span>';
                                        
                                        if ($current_page < $total_pages) {
                                            echo '<a class="next-page button" href="' . esc_url($base_url . '&paged=' . ($current_page + 1)) . '">›</a>';
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
