<?php
/**
 * Import/Export Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap hpcf-admin-wrap">
    <h1 class="wp-heading-inline">
        <span class="dashicons dashicons-upload"></span>
        <?php esc_html_e('Import / Export Data', 'hivepress-conditional-fields'); ?>
    </h1>

    <div class="hpcf-admin-container hpcf-import-export">
        <?php if (empty($pairs)): ?>
            <div class="hpcf-empty-state">
                <span class="dashicons dashicons-warning"></span>
                <p><?php esc_html_e('No active field pairs found. Create a field pair first.', 'hivepress-conditional-fields'); ?></p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=hpcf-settings')); ?>" class="button button-primary">
                    <?php esc_html_e('Create Field Pair', 'hivepress-conditional-fields'); ?>
                </a>
            </div>
        <?php else: ?>
            <!-- Import Section -->
            <div class="hpcf-section">
                <h2>
                    <span class="dashicons dashicons-upload"></span>
                    <?php esc_html_e('Import CSV', 'hivepress-conditional-fields'); ?>
                </h2>
                
                <div class="hpcf-import-info">
                    <h4><?php esc_html_e('CSV Format', 'hivepress-conditional-fields'); ?></h4>
                    <p><?php esc_html_e('Your CSV file should have two columns:', 'hivepress-conditional-fields'); ?></p>
                    <pre>parent_value,child_value
Toyota,Camry
Toyota,Corolla
Toyota,RAV4
Honda,Accord
Honda,Civic</pre>
                    <p class="description">
                        <?php esc_html_e('No header row required. Each line represents one parent-child relationship.', 'hivepress-conditional-fields'); ?>
                    </p>
                </div>
                
                <form id="hpcf-import-form" enctype="multipart/form-data">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="import_pair_id"><?php esc_html_e('Field Pair', 'hivepress-conditional-fields'); ?></label>
                            </th>
                            <td>
                                <select name="pair_id" id="import_pair_id" required>
                                    <option value=""><?php esc_html_e('Select a field pair', 'hivepress-conditional-fields'); ?></option>
                                    <?php foreach ($pairs as $pair): ?>
                                        <option value="<?php echo esc_attr($pair->id); ?>">
                                            <?php echo esc_html($pair->pair_name . ' (' . $pair->parent_field_label . ' → ' . $pair->child_field_label . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="csv_file"><?php esc_html_e('CSV File', 'hivepress-conditional-fields'); ?></label>
                            </th>
                            <td>
                                <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
                                <p class="description"><?php esc_html_e('Maximum file size: 10MB. UTF-8 encoding recommended.', 'hivepress-conditional-fields'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Options', 'hivepress-conditional-fields'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="clear_existing" id="clear_existing" value="1">
                                    <?php esc_html_e('Clear existing data before import', 'hivepress-conditional-fields'); ?>
                                </label>
                                <p class="description"><?php esc_html_e('Warning: This will delete all existing entries for the selected field pair.', 'hivepress-conditional-fields'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary" id="hpcf-import-btn">
                            <span class="dashicons dashicons-upload"></span>
                            <?php esc_html_e('Import CSV', 'hivepress-conditional-fields'); ?>
                        </button>
                    </p>
                </form>
                
                <!-- Import Progress/Results -->
                <div id="hpcf-import-progress" style="display: none;">
                    <div class="hpcf-progress-bar">
                        <div class="hpcf-progress-fill"></div>
                    </div>
                    <p class="hpcf-progress-text"><?php esc_html_e('Importing...', 'hivepress-conditional-fields'); ?></p>
                </div>
                
                <div id="hpcf-import-results" style="display: none;"></div>
            </div>

            <!-- Export Section -->
            <div class="hpcf-section">
                <h2>
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e('Export CSV', 'hivepress-conditional-fields'); ?>
                </h2>
                
                <form id="hpcf-export-form" method="get" action="<?php echo admin_url('admin-ajax.php'); ?>">
                    <input type="hidden" name="action" value="hpcf_export_csv">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('hpcf_admin_nonce'); ?>">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="export_pair_id"><?php esc_html_e('Field Pair', 'hivepress-conditional-fields'); ?></label>
                            </th>
                            <td>
                                <select name="pair_id" id="export_pair_id" required>
                                    <option value=""><?php esc_html_e('Select a field pair', 'hivepress-conditional-fields'); ?></option>
                                    <?php foreach ($pairs as $pair): ?>
                                        <option value="<?php echo esc_attr($pair->id); ?>">
                                            <?php echo esc_html($pair->pair_name . ' (' . $pair->parent_field_label . ' → ' . $pair->child_field_label . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-secondary" id="hpcf-export-btn">
                            <span class="dashicons dashicons-download"></span>
                            <?php esc_html_e('Export CSV', 'hivepress-conditional-fields'); ?>
                        </button>
                    </p>
                </form>
            </div>

            <!-- Sample CSV Download -->
            <div class="hpcf-section hpcf-section-small">
                <h3><?php esc_html_e('Need a sample CSV?', 'hivepress-conditional-fields'); ?></h3>
                <p><?php esc_html_e('Download a sample CSV file to see the correct format:', 'hivepress-conditional-fields'); ?></p>
                <a href="<?php echo esc_url(HPCF_PLUGIN_URL . 'assets/sample/sample_data.csv'); ?>" class="button" download>
                    <span class="dashicons dashicons-media-text"></span>
                    <?php esc_html_e('Download Sample CSV', 'hivepress-conditional-fields'); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
